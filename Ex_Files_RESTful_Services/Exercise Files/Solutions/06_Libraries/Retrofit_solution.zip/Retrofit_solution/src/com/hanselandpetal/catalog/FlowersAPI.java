package com.hanselandpetal.catalog;

import java.util.List;

import com.hanselandpetal.catalog.model.Flower;

import retrofit.Callback;
import retrofit.http.GET;

public interface FlowersAPI {

	@GET("/feeds/flowers.json")
	public void getFeed(Callback<List<Flower>> response);
	
}
